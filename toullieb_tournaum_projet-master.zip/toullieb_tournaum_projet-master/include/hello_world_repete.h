#ifndef _AFFICHE_H
#define _AFFICHE_H

void affiche_hello_world(void);
void affichage_repete(unsigned nb_repetitions);

#endif
