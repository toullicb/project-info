#ifndef _STRUCTURES_H_
#define _STRUCTURES_H_


// Structure pour representer un vecteur
typedef struct vector {
    double x;
    double y;
} vector;

// Structure pour reprsenter un corps
typedef struct body {
    double mass;
    vector pos;
    vector vel;
} body;
#endef
