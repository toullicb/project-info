#include <stdio.h>

//définition de la strcture vecteur
typedef struct vector {
  double x; double y;
} vector_t;

//définition de la structure corps
typedef struct corps {
  vector position; vector v; double m;
} corps_t;


//Création d'une matrice 2D
int univers[100][100];


//définition de l'image PGM univers
//Création d'un fichier de type P2 (niv de gris)
//pix : matrice qui stocke les valeurs des pixels
//nom : nom du fichier
//max : valeur maximale de codage (255)

void creer_fichier_image_P2(pix,nom,max):
  char largeur; char hauteur; char valmax;char pixel;
  h=len(pix);				/* hauteur de l'image*/
	l=len(pix[0]);				/*largeur de l'image*/
	nom = nom + '.pgm';		/*ajoute l'extension.pgm*/
	fichier = fopen("nom.txt","w");	/*crée le fichier texte*/
  sprintf(largeur,"%d",l);/*transforme la valeur l en texte*/
  sprintf(hauteur,"%d",h);/*transforme la valeur h en texte*/
  sprintf(valmax,"%d",max);	/*transforme la valeur max en texte*/
	fwrite(fichier,"%lf",P2\n'+largeur+' '+hauteur+'\n'+valmax+'\n'); /*écrit l'entête*/
	for (i=0,i<h,i++){
		for (j=0,j<l,j++){
			pixel=sprintf(pixel,"d",pix[i][j]); //la valeur du pixel est convertie en texte
			sprintf(fichier,"%lf",pixel);//enregistre un pixel en mode texte

    }
  }
  fclose(fichier);
