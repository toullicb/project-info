#include <stdio.h>
#include <stdlib.h>

#include "hello_world_repete.h"

int main(void)
{
  affiche_hello_world();
  exit(EXIT_SUCCESS);
}
