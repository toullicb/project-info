#include <stdio.h>
#include <math.h>

#define G 6.67430e-11  // Constante de gravitation universelle
#define UNIV_SIZE 1000  // Taille de l'univers (en units arbitraires)

// Structure pour reprsenter un vecteur
typedef struct {
    double x;
    double y;
} vector;

// Structure pour reprsenter un corps
typedef struct {
    double mass;
    vector pos;
    vector vel;
} body;

// Fonction pour calculer la distance entre deux vecteurs
double distance(vector v1, vector v2) {
    double dx = v2.x - v1.x;
    double dy = v2.y - v1.y;
    return sqrt(dx*dx + dy*dy);
}

// Fonction pour calculer la force gravitationnelle entre deux corps
vector gravity_force(body b1, body b2) {
    vector r;
    r.x = b2.pos.x - b1.pos.x;
    r.y = b2.pos.y - b1.pos.y;
    double d = distance(b1.pos, b2.pos);
    double f = G * b1.mass * b2.mass / (d*d*d);
    vector f_grav;
    f_grav.x = f * r.x;
    f_grav.y = f * r.y;
    return f_grav;
}

// Vérification de la position du corps avec un retour à l'opposé de l'univers si le corps dépasse la distance de la carte
void space_verif(body b1) {
    while (b1.pos.x<-UNIV_SIZE){
        b1.pos.x+=2*UNIV_SIZE
    }
    while (b1.pos.y<-UNIV_SIZE){
        b1.pos.y+=2*UNIV_SIZE
    }
    while (b1.pos.x>UNIV_SIZE){
        b1.pos.x=b1.pos.x-2*UNIV_SIZE
    }
    while (b1.pos.y>UNIV_SIZE){
        b1.pos.y=b1.pos.y-2*UNIV_SIZE
    }
}

int main() {
    int num_bodies = 2;  // Nombre de corps
    body bodies[num_bodies];  // Tableau de corps

    // Initialisation des corps
    bodies[0].mass = 1e10;
    bodies[0].pos.x = 200;
    bodies[0].pos.y = 500;
    bodies[0].vel.x = 0;
    bodies[0].vel.y = 0;

    bodies[1].mass = 2e10;
    bodies[1].pos.x = 800;
    bodies[1].pos.y = 500;
    bodies[1].vel.x = 0;
    bodies[1].vel.y = 0;

    double dt = 1000;  // Pas de simulation
    int num_steps = 10000;  // Nombre d'tapes de simulation

    // Simulation
    for (int step = 0; step < num_steps; step++) {
        // Calcul des forces gravitationnelles
        vector forces[num_bodies];
        for (int i = 0; i < num_bodies; i++) {
            vector force;
            force.x = 0;
            force.y = 0;
            for (int j = 0; j < num_bodies; j++) {
                if (i != j) {
                    vector f_grav = gravity_force(bodies[i], bodies[j]);
                    force.x += f_grav.x;
                    force.y += f_grav.y;
                }
            }
            forces[i] = force;
        }

        // Mise  jour des positions et des vitesses des corps
        for (int i = 0; i < num_bodies; i++) {
            bodies[i].pos.x += dt * bodies[i].vel.x;
            bodies[i].pos.y += dt * bodies[i].vel.y;
            vector accel;
            accel.x = forces[i].x / bodies[i].mass;
            accel.y = forces[i].x / bodies[i].mass;
            bodies[i].vel.x += dt * accel.x;
            bodies[i].vel.y += dt * accel.y;
        }}
    printf("La position finale du corps 1 est: (%lf,%lf)\n Sa vitesse est : (%lf,%lf)\n",bodies[0].pos.x,bodies[0].pos.y,bodies[0].vel.x,bodies[0].vel.y);
    return 0;
        }

