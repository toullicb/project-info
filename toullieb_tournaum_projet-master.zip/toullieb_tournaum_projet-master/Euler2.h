#include <stdio.h>
#include <math.h>
#include "structures.h"
// Fonction pour calculer la distance entre deux vecteurs
double distance(vector v1, vector v2);

// Fonction pour calculer la force gravitationnelle entre deux corps
vector gravity_force(body b1, body b2);

// Vérification de la position du corps avec un retour à l'opposé de l'univers si le corps dépasse la distance de la carte
void space_verif(body b1);
