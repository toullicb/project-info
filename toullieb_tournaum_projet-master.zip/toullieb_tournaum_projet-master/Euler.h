#ifndef EULER_H_INCLUDED
#define EULER_H_INCLUDED

#include <stdio.h>
#include <math.h>

#define G 6.67430e-11  // Constante de gravitation universelle
#define UNIV_SIZE 1000  // Taille de l'univers (en unit�s arbitraires)

// Structure pour repr�senter un vecteur
typedef struct {
    double x;
    double y;
} vector;

// Structure pour repr�senter un corps
typedef struct {
    double mass;
    vector pos;
    vector vel;
} body;

// Fonction pour calculer la distance entre deux vecteurs
double distance(vector v1, vector v2) {
    double dx = v2.x - v1.x;
    double dy = v2.y - v1.y;
    return sqrt(dx*dx + dy*dy);
}

// Fonction pour calculer la force gravitationnelle entre deux corps
vector gravity_force(body b1, body b2) {
    vector r;
    r.x = b2.pos.x - b1.pos.x;
    r.y = b2.pos.y - b1.pos.y;
    double d = distance(b1.pos, b2.pos);
    double f = G * b1.mass * b2.mass / (d*d*d);
    vector f_grav;
    f_grav.x = f * r.x;
    f_grav.y = f * r.y;
    return f_grav;
}






#endif // EULER_H_INCLUDED
