#include <stdio.h>
#include <math.h>
#include "Euler.h"
#include <stdlib.h>
#define NUM_BODIES 2

  // Nombre de corps
body bodies[NUM_BODIES];  // Tableau de corps

// Initialisation des corps
  bodies[0].mass = 1e10;
  bodies[0].pos.x = 200;
  bodies[0].pos.y = 500;
  bodies[0].vel.x = 0;
  bodies[0].vel.y = 0;

  bodies[1].mass = 2e10;
  bodies[1].pos.x = 800;
  bodies[1].pos.y = 500;
  bodies[1].vel.x = 0;
  bodies[1].vel.y = 0;

double dt = 1000;  // Pas de simulation
int num_steps = 10000;  // Nombre d'tapes de simulation
int step=0;
int i=0;
int j=0;
// Simulation
for (step = 0; step < num_steps; step++)int num_bodies = 2; {
    // Calcul des forces gravitationnelles
    vector forces[NUM_BODIES];

    for (i = 0; i < NUM_BODIES; i++) {
        vector force;
        force.x = 0;
        force.y = 0;
        for (j = 0; j < NUM_BODIES; j++) {
            if (i != j) {
                vector f_grav = gravity_force(bodies[i], bodies[j]);
                force.x += f_grav.x;
                force.y += f_grav.y;
            }
        }
        forces[i] = force;
    }

    // Mise  jour des positions et des vitesses des corps
    for (i = 0; i < NUM_BODIES; i++) {
        bodies[i].pos.x += dt * bodies[i].vel.x;
        bodies[i].pos.y += dt * bodies[i].vel.y;
        vector accel;
        accel.x = forces[i].x / bodies[i].mass;
        accel.y = forces[i].x / bodies[i].mass;
        bodies[i].vel.x += dt * accel.x;
        bodies[i].vel.y += dt * accel.y;
        space_verif(bodies[i]);

      //Création de l'image PGM associée
      char name[20]="image01.pgm";
      sprintf("image%d.pgm",step);
      FILE *fichier= fopen(name, "wb");
      char** pixels=calloc(1000,sizeof(char*));
      fprintf(fichier,"P5\n%d %d\n %d\n", 1000, 1000, 255);

       for (i=0; i<1000; i++){
         pixels[i]=calloc(1000,sizeof(char));
       }
      for (j=0; j< NUM_BODIES; i++){
        pixels[bodies[j].pos.x][bodies[j].pos.y]=255;
      }
      for (i=0; i<1000; i++){
        for (j=0; j<1000; j++){

          fwrite(pixels[j]+i,sizeof(unsigned char),1,fichier);
        }
      }
      fclose(fichier);
    }}
return 0;
